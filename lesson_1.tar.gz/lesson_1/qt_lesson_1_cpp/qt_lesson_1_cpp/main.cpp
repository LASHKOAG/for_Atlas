#include <iostream>

using namespace std;

int main()
{
    int var = 25;
    char str[] = "Well done\n";
    cout << "Hello World!" << endl;
    cout << 15 << endl;
    cout << var << endl;
    cout << str << endl;
    cout << 2+2 << endl;
    return 0;
}
