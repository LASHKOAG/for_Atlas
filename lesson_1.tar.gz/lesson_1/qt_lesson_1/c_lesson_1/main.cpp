#include <stdio.h>

int main(){
    int var = 25;
    int var2 = 25;
    int var3 = 25;
    printf("Hello, world!\n");

    printf("This number is: %d\n", var);

    printf("This number is: %d  %s  %f\n", var, var2, var3);

    return 0;
}
