function func() {
    console.log("Hello from js!");
}
